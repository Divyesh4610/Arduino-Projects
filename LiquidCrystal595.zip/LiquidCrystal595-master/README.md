# LiquidCrystal595
Connect a 16x2 LCD with 3 instead of 6 pins.

Original Arduino libary from [rowansimms]<br />
https://bitbucket.org/rowansimms/arduino-lcd-3pin

# Installation
Copy LiquidCrystal595 folder to Arduino folder.<br />
Include it in your Adruino sketch.

# Project page
http://hpham.gq/2013/ket-noi-lcd-voi-arduino-trong-6-giay
